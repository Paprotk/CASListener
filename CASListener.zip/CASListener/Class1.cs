﻿using System.Collections.Generic;
using Sims3.Gameplay.Utilities;
using Sims3.SimIFace;
using Sims3.UI;

namespace Arro.MCR
{
    // Token: 0x02000006 RID: 6
    public class TwoStringDialogMCR : TwoStringInputDialog
    {
        // Token: 0x06000010 RID: 16 RVA: 0x0000238F File Offset: 0x0000138F
        public static List<string> Show(string defaultEntryText, string defaultSecondEntryText, string oKText, string cancelText)
        {
            return TwoStringDialogMCR.Show(defaultEntryText, defaultSecondEntryText, oKText, cancelText, new Vector2(-1f, -1f), false);
        }

        // Token: 0x06000011 RID: 17 RVA: 0x000023AA File Offset: 0x000013AA
        public static List<string> Show(string defaultEntryText, string defaultSecondEntryText, string oKText, string cancelText, bool verifyFilename)
        {
            return TwoStringDialogMCR.Show(defaultEntryText, defaultSecondEntryText, oKText, cancelText, new Vector2(-1f, -1f), verifyFilename);
        }

        // Token: 0x06000012 RID: 18 RVA: 0x000023C8 File Offset: 0x000013C8
        public static List<string> Show(string defaultEntryText, string defaultSecondEntryText, string oKText, string cancelText, Vector2 position, bool verifyFilename)
        {
            if (ModalDialog.EnableModalDialogs)
            {
                using (TwoStringDialogMCR dateInputDialog = new TwoStringDialogMCR(defaultEntryText, defaultSecondEntryText, oKText, cancelText, position, verifyFilename))
                {
                    dateInputDialog.StartModal();
                    return dateInputDialog.Result;
                }
            }
            return null;
        }

        // Token: 0x06000013 RID: 19 RVA: 0x00002418 File Offset: 0x00001418
        public TwoStringDialogMCR(string defaultEntryText, string defaultSecondEntryText, string oKText, string cancelText, Vector2 position, bool verifyFilename) : base("CustomInputDialog", 4096, "", "", "", defaultEntryText, defaultSecondEntryText, oKText, cancelText, position, verifyFilename)
        {
            if (this.mModalDialogWindow != null)
            {
                Text text = this.mModalDialogWindow.GetChildByID(7U, true) as Text;
                if (text != null)
                {
                    text.Caption = Localization.LocalizeString("Arro/MCR/Local:ConfigureGrid", new object[0]);
                }
                Text text2 = this.mModalDialogWindow.GetChildByID(1U, true) as Text;
                if (text2 != null)
                {
                    text2.Caption = Localization.LocalizeString("Arro/MCR/Local:RowCount", new object[0]);
                }
                Text text3 = this.mModalDialogWindow.GetChildByID(6U, true) as Text;
                if (text3 != null)
                {
                    text3.Caption = Localization.LocalizeString("Arro/MCR/Local:ColumnCount", new object[0]);
                }
            }
        }

        // Token: 0x04000007 RID: 7
        public new const string kLayoutName = "CustomInputDialog";

        // Token: 0x04000008 RID: 8
        public new const int kWinExportID = 4096;
    }
}
